/**
 * Appwrite Function entrypoint for the administrator dashboard backend. Settings (function variables, never in the frontend):
 *   APPWRITE_API_KEY  Appwrite key with scopes users.read, rows.read, rows.write  (the ONLY writer of departments, categories,
 *                     department_users and admin_audit)
 *   DATABASE_ID       the database ID
 *   Optional table IDs (defaults match the schema): USERS_TABLE_ID, DEPARTMENTS_TABLE_ID, CATEGORIES_TABLE_ID,
 *   DEPARTMENT_USERS_TABLE_ID, COMPLAINTS_TABLE_ID, ADMIN_AUDIT_TABLE_ID
 * Function "Execute access": Users (any signed-in user). The handler lets ONLY administrators through, on every call.
 */
import { Account, Client, ID, Query, TablesDB, Users } from 'node-appwrite'
import { handle } from './handler.js'

const PAGE = 100
const MAX = 5000

const orNull = (error) => {
  if (error?.code === 404) return null
  throw error
}

async function listAllPages(fetchPage, max = MAX) {
  const rows = []
  while (rows.length < max) {
    const page = await fetchPage([Query.limit(PAGE), Query.offset(rows.length)])
    rows.push(...page.rows)
    if (page.rows.length < PAGE) break
  }
  return rows
}

export function createDeps({ endpoint, projectId, apiKey, databaseId, ids, log }) {
  const admin = new Client().setEndpoint(endpoint).setProject(projectId).setKey(apiKey)
  const users = new Users(admin)
  const tables = new TablesDB(admin)
  const list = (tableId, queries = []) => tables.listRows({ databaseId, tableId, queries })
  const all = (tableId, queries = [], max) => listAllPages((paging) => list(tableId, [...queries, ...paging]), max)
  const get = (tableId, rowId) => tables.getRow({ databaseId, tableId, rowId }).catch(orNull)
  const count = async (tableId, queries = []) => (await list(tableId, [...queries, Query.limit(1)])).total

  const records = (tableId) => ({
    get: (id) => get(tableId, id),
    listAll: () => all(tableId),
    create: (data) => tables.createRow({ databaseId, tableId, rowId: ID.unique(), data }),
    update: (id, data) => tables.updateRow({ databaseId, tableId, rowId: id, data }),
    count: async ({ status } = {}) => count(tableId, status ? [Query.equal('status', [status])] : []),
  })

  return {
    log,
    async verifyJwt(jwt) {
      const asUser = new Client().setEndpoint(endpoint).setProject(projectId).setJWT(jwt)
      return (await new Account(asUser).get()).$id
    },
    users: { get: (userId) => users.get({ userId }).catch(orNull) },
    userRows: {
      get: (id) => get(ids.users, id),
      count: ({ role }) => count(ids.users, [Query.equal('role', [role])]),
      listByRole: (role, max) => all(ids.users, [Query.equal('role', [role])], max),
    },
    departments: records(ids.departments),
    categories: records(ids.categories),
    departmentUsers: {
      get: (id) => get(ids.departmentUsers, id),
      listAll: () => all(ids.departmentUsers),
      listByDepartment: (departmentId) => all(ids.departmentUsers, [Query.equal('departmentId', [departmentId]), Query.orderAsc('$createdAt')]),
      listByUser: (userId) => all(ids.departmentUsers, [Query.equal('userId', [userId])]),
      create: (data) => tables.createRow({ databaseId, tableId: ids.departmentUsers, rowId: ID.unique(), data }),
      update: (id, data) => tables.updateRow({ databaseId, tableId: ids.departmentUsers, rowId: id, data }),
      remove: (id) => tables.deleteRow({ databaseId, tableId: ids.departmentUsers, rowId: id }),
    },
    complaints: {
      /** Counts only (no rows are read). Filters: status, statuses, categoryId, departmentId. */
      count: ({ status, statuses, categoryId, departmentId }) =>
        count(ids.complaints, [
          ...(status ? [Query.equal('status', [status])] : []),
          ...(statuses ? [Query.equal('status', statuses)] : []),
          ...(categoryId ? [Query.equal('categoryId', [categoryId])] : []),
          ...(departmentId ? [Query.equal('departmentId', [departmentId])] : []),
        ]),
      /** The newest resolved/closed complaints, for resolution-time statistics. */
      listFinished: (max) => all(ids.complaints, [Query.equal('status', ['resolved', 'closed']), Query.orderDesc('$createdAt')], max),
    },
    audit: {
      record: (entry) => tables.createRow({ databaseId, tableId: ids.audit, rowId: ID.unique(), data: entry, permissions: ['read("label:admin")'] }),
      list: async (limit) => (await list(ids.audit, [Query.orderDesc('createdAt'), Query.orderDesc('$createdAt'), Query.limit(limit)])).rows,
    },
  }
}

export default async ({ req, res, error }) => {
  const endpoint = process.env.APPWRITE_FUNCTION_API_ENDPOINT
  const projectId = process.env.APPWRITE_FUNCTION_PROJECT_ID
  const apiKey = process.env.APPWRITE_API_KEY || req.headers['x-appwrite-key']
  const databaseId = process.env.DATABASE_ID
  if (!endpoint || !projectId || !apiKey || !databaseId) {
    error('admin-api is not configured: set APPWRITE_API_KEY and DATABASE_ID in the function settings.')
    return res.json({ ok: false, error: { code: 'server_misconfigured', message: 'The administration service is not configured.' } }, 500)
  }
  const ids = {
    users: process.env.USERS_TABLE_ID || 'users',
    departments: process.env.DEPARTMENTS_TABLE_ID || 'departments',
    categories: process.env.CATEGORIES_TABLE_ID || 'categories',
    departmentUsers: process.env.DEPARTMENT_USERS_TABLE_ID || 'department_users',
    complaints: process.env.COMPLAINTS_TABLE_ID || 'complaints',
    audit: process.env.ADMIN_AUDIT_TABLE_ID || 'admin_audit',
  }
  const { status, body } = await handle({ req }, createDeps({ endpoint, projectId, apiKey, databaseId, ids, log: error }))
  return res.json(body, status)
}
